#### fix c_v before doing any more science ####

import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
import scipy.interpolate as interpol


# goal: to interpolate Sirko & Goodman fits and then take derivatives
# get the torque vs radius for a SMBH accretion disk.

# # # # # # # # # # # # # # # # # # # # # # # # 
# CONSTANTS AND INPUT VARIABLES
# # # # # # # # # # # # # # # # # # # # # # # # 
M_SMBH = 1e8            # guess at SMBH mass!
#M_SMBH = 1e9
M_IMBH = 100.0           # what is the IMBH mass?  Who knows right now.
q = M_IMBH/M_SMBH       # ratio of planet/central object masses. 
Gcgs = 6.67e-8          # G in cgs units.  
cv = 12.5               # 12.5 monatomic gas, 20.8 diatomic.
#### this is wrong should be 12.5e7 !!!!! ######  change before doing anything
sigma_SB = 5.67e-5      # cgs units!
speedoflight = 3e10     # cm / s
Msung = 2e33            # convert solar mass to grams
M_SMBH_gram = M_SMBH*Msung
#M_SMBH_gram2 = M_SMBH2*Msung
Rs = 2*Gcgs*M_SMBH_gram/speedoflight**2  # schwartzshield radius in cm
#Rs2 = 2*Gcgs*M_SMBH_gram2/speedoflight**2  # schwartzshield radius in cm
pctocm = 3.0856776e+18  # parsecs to cm
# # # # # # # # # # # # # # # # # # # # # # # # 

#  FUNCTIONS
##############################
# take a derivative 
##############################
def derivative(x,y):
    """ returns derivative of one array wrt the other.
        result is one element shorter than original arrays, hmm """
    if len(x) != len(y):
        print "x and y must have equal lengths"
    result =[]
    for element in range(len(x)-1):
        dy = y[element+1]-y[element]
        dx = x[element+1]-x[element]
        result.append(dy/dx)
    result.append(result[-1]) # append the final value onto the end!
    # this is sketchy.
    return result

###############################################
#  Let's find the migration traps with math
###############################################
def findtrap(R,Torque):
    trap=[]
    for i in range(len(Torque)-1):
        if Torque[i] > 0 and Torque[i+1] < 0:
            trap.append(i)
    trapradius=[]
    for j in range(len(trap)):
        ###print R[trap[j]]
        trapradius.append(R[trap[j]])
    return trapradius

### this one finds the unstable traps ###
def finduntrap(R,Torque):
    untrap=[]
    for i in range(len(Torque)-1):
        if Torque[i] < 0 and Torque[i+1] > 0:
            untrap.append(i)
    untrapradius=[]
    for j in range(len(untrap)):
        ###print R[trap[j]]
        untrapradius.append(R[untrap[j]])
    return untrapradius
####################################

### Temperature vs Radius data ###
r1,temp = np.loadtxt("Temp.txt",unpack=True,delimiter=",")
logschwarzradius = np.arange(5500)/1000.  # this is log R/Rs
#logradius = np.arange(5500)/1000.  # this is log R/Rs
# radius needs to be within the bounds of r1
awesome = []
for item in logschwarzradius:
    if item > min(r1) and item < max(r1):
        awesome.append(item)
radiuscm = np.power(10,awesome)*Rs
radiuspc = radiuscm/pctocm
logradius = np.log10(radiuspc)  # new radius in log pc
# rescale r1 as well
r1 = np.log10(np.power(10,r1)*Rs/pctocm) # convert Log R/Rs to Log pc
logRg = awesome

### Temperature INTERPOLATION ###
# quick and dirty interpolation
f = interpol.interp1d(r1,temp)
tnew = f(logradius)
# spline interpolation
f2 = interpol.splrep(r1,temp,s=0)
tnew2 = interpol.splev(logradius,f2,der=0)

"""plt.subplot(221)
plt.plot(r1,temp,"o",logradius,tnew,"-",logradius,tnew2,"--")
plt.xlabel("log R/Rs")
plt.ylabel("log T (K)")
#plt.show()"""

# need to un-log our values.
radius = np.power(10,logradius)
unlogtemp = np.power(10,tnew)
unlogtemp2 = np.power(10,tnew2)

# let's calculate the derivative of our new function.

# sympy
# numpy.diff
# numpy.gradient
# scipy.misc.derivative  -  this is the one to try.
#import sympy
#meow = sympy.mpmath.diff(tnew,logradius)

d1temp = derivative(np.log(radiuscm),np.log(unlogtemp))
d2temp = derivative(np.log(radiuscm),np.log(unlogtemp2))
#d2temp2 = derivative(np.log(np.array(radius)*Rs2),np.log(unlogtemp2))

"""plt.subplot(222)
plt.plot(logradius,d1temp,logradius,d2temp)
plt.ylabel("d ln T/d ln R")
plt.xlabel("log R (pc)")
"""

# let's repeat this in log pc
#radius_parsec = np.array(radius)*Rs/pctocm
#radius_parsec2 = np.array(radius)*Rs2/pctocm
#log_radius_parsec = np.log10(radius_parsec)
#log_radius_parsec2 = np.log10(radius_parsec2)
#plt.subplot(223)
#plt.plot(log_radius_parsec,tnew2,log_radius_parsec2,tnew2)
#plt.xlabel("log radius (parsec)")

#parsecd2temp = derivative(np.log(radius_parsec),np.log(unlogtemp2))
#parsecd2temp2 = derivative(np.log(radius_parsec2),np.log(unlogtemp2))
#plt.subplot(224)
#plt.plot(log_radius_parsec,parsecd2temp,log_radius_parsec2,parsecd2temp2)
#plt.ylabel("d ln T/d ln R")
#plt.xlabel("log radius (pc)")
#plt.show()

###########  now for surface density ##############
r2,Sigma = np.loadtxt("SurfaceDensity.txt",unpack=True,delimiter=",")
r2 = np.log10(np.power(10,r2)*Rs/pctocm) # convert Log R/Rs to Log pc

# interpolate
f = interpol.interp1d(r2,Sigma)
tnew = f(logradius)
f2 = interpol.splrep(r2,Sigma,s=0)
tnew2 = interpol.splev(logradius,f2,der=0)

#plt.subplot(223)
#plt.plot(r2,Sigma,"o",logradius,tnew,"-",logradius,tnew2,"--")
#plt.xlabel("log R/Rs")
#plt.ylabel("log Surface Density")

# unlog the quantities for derivative-ing
unlogsigma = np.power(10,tnew)
unlogsigma2 = np.power(10,tnew2)


d1sigma = derivative(np.log(radiuscm),np.log(unlogsigma))
d2sigma = derivative(np.log(radiuscm),np.log(unlogsigma2))

#plt.subplot(224)
#plt.plot(logradius,d1sigma,logradius,d2sigma)
#plt.ylabel("d ln(Sigma)/d ln R")
#plt.xlabel("log R/Rs")
#plt.show()


#### other quantities I need ####
### half-height of disk h ###
rh,loghoverr = np.loadtxt("hoverr.txt",unpack=True,delimiter=",")
rh = np.log10(np.power(10,rh)*Rs/pctocm) # convert Log R/Rs to Log pc

# interpolate h
f2 = interpol.splrep(rh,loghoverr,s=0)
hnew2 = interpol.splev(logradius,f2,der=0)  # note this is log h/r, not h
hoverr = np.power(10,hnew2) # disk aspect ratio

# need tau_eff, start with tau.
rtau, logtau = np.loadtxt("tau.txt",unpack=True,delimiter=",")
rtau = np.log10(np.power(10,rtau)*Rs/pctocm) # convert Log R/Rs to Log pc

f2tau = interpol.splrep(rtau,logtau,s=0)
taunew2 = interpol.splev(logradius,f2tau,der=0)
tau = np.power(10.0,taunew2)  # unlog the tau
taueff = (3.*np.array(tau))/8. + np.sqrt(3.)/4. + 1./(4.*np.array(tau)) # from Lyra+10

#plt.subplot(211)
#plt.plot(logradius,tau)
#plt.yscale("log")
#plt.subplot(212)
#plt.plot(logradius,taueff)
#plt.yscale("log")
#plt.show()

Omega = np.sqrt(Gcgs*M_SMBH_gram/(radiuscm)**3) # is Keplerian Frequency same as ang vel?
Gamma_0 = (q/hoverr)**2 * unlogsigma * (radiuscm)**4 * np.array(Omega)**2
Theta = (cv*unlogsigma*Omega*taueff)/(12*np.pi*sigma_SB*unlogtemp2**3)
print Theta
print "that was theta"

####  now let's calculate some torques.  ####

alpha = -1.0 *np.array(d2sigma)
beta =  (-1.0) * np.array(d2temp)
gamma = 1.667  # monotonic gas, not 1.4 as in Lyra+10
xi = beta - np.array(alpha)*(gamma-1.0)

Gamma_iso = -0.85 - alpha - 0.9*beta 
Gamma_ad = (-0.85 - alpha - 1.7*beta + 7.9*xi/gamma)/gamma

# plot some test quantities
#plt.subplot(221)
#plt.plot(logradius,taueff)
#plt.yscale("log")
#plt.xlabel("Log R/Rs")
#plt.ylabel("taueff")
#plt.subplot(222)
#plt.plot(logradius,Omega)
#plt.yscale("log")
#plt.ylabel("Omega  sqrt(GM/r^3)")
#plt.xlabel("Log R/Rs")
#plt.show()
#plt.subplot(223)
#plt.plot(logradius,np.log10(hoverr))
#plt.ylabel("Log h/r")
#plt.xlabel("Log R/Rs")
plt.subplot(211)
plt.plot(logradius,Gamma_iso,"b-",logradius,Gamma_ad,"g-")
plt.ylabel("Gammas")
plt.xlabel("Log R/Rs")
#plt.show()

#plt.subplot(221)
#plt.plot(logradius,Gamma_0)
#plt.xlabel("log R/Rs")
#plt.ylabel("Gamma_0")
plt.subplot(212)
plt.plot(logradius,derivative(radiuscm,Theta**2))
plt.ylabel("dTheta**2/dr")
#plt.yscale("log")
#plt.subplot(223)
#plt.plot(logradius,xi)
#plt.ylabel("xi")
#plt.show()


Torque = (Gamma_ad*np.array(Theta)**2 + Gamma_iso)*Gamma_0 / (np.array(Theta)+1)**2
print Torque/Gamma_0
print min(Torque/Gamma_0),max(Torque/Gamma_0)
#print min(hoverr),max(hoverr)
trapradius = findtrap(logRg,Torque)
print trapradius, "log  Rs"
untrap = finduntrap(logRg,Torque)
#print np.power(10,trapradius), " parsecs"


# rescale?
#Torque = Torque * unlogsigma2/unlogtemp2

#plt.subplot(211)
#plt.plot(logradius,np.abs(Torque))
#plt.xlabel("Log Radius R/Rs")
#plt.ylabel("Abs Torque (cgs units)")
#plt.yscale("log")
#plt.plot(logradius,np.zeros(len(logradius)),"r--")

#########################
## plotting the result ##
#########################
import matplotlib.axes as ax
from pylab import axes
"""
#plt.subplot(311)
a=axes([.125,.65,.775,.25])
plt.plot(logRg,Torque/1e49)
#plt.xlabel("Log Radius R/Rs")
#plt.ylabel("$\Gamma/1e49$")
plt.plot(logRg,np.zeros(len(logRg)),"r--")
ax.Axes.set_ylabel(a,"$\Gamma/1e49$",labelpad=0,size=20)
plt.tick_params(axis='x',which='both',bottom='on',top='on',labelbottom='off') 


#plt.subplot(312)
a=axes([0.125,0.4,0.775,0.25])
plt.plot(logRg,Torque/1e32)
#plt.xlabel("Log Radius R/Rs")
plt.ylabel("$\Gamma/1e32$")
plt.ylim(-1,1)
plt.plot(logRg,np.zeros(len(logRg)),"r--")
plt.tick_params(axis='x',which='both',bottom='on',top='on',labelbottom='off') 
ax.Axes.set_ylabel(a,"$\Gamma/1e32$",labelpad=0,size=20)


#plt.subplot(313)
a=axes([0.125,0.15,0.775,0.25])
plt.plot(logRg,abs(Torque/1e49))
#plt.xlabel("Log Radius (R/R$_g$)")
plt.ylabel("$|\Gamma|/1e49$ ")
plt.ylim(1e-12,10)
plt.yscale("log")
ax.Axes.set_xlabel(a,"Log Radius (R/R$_g$)",labelpad=15,size=20)
ax.Axes.set_ylabel(a,"$|\Gamma|/1e49$ ",labelpad=-7,size=20)
ax.Axes.set_yticks(a,[1e-12,1e-10,1e-8,1e-6,1e-4,1e-2])

plt.show()
#plt.savefig("torque.png")
#plt.savefig("torque_pretty3.png")
"""
##########################
## make an inset plot  ##
##########################

import matplotlib.axes as ax
from pylab import axes

a = axes([0.1,0.15,.8,.8])
plt.plot(logRg,Torque/1e49,"k-")
plt.axis([0.0,5.0,-1.0,0.4])
#plt.xlabel("Log Radius R/R$_g$")
#plt.ylabel("$\Gamma/1e49$")
ax.Axes.set_ylabel(a,"$\Gamma/1e49$",labelpad=0,size=20)
ax.Axes.set_xlabel(a,"Log Radius (R/R$_g$)",labelpad=5,size=20)
plt.plot(logRg,np.zeros(len(logRg)),"r--")


insetaxes = axes([.18,.82,.4,.1])
plt.plot(logRg,Torque/1e32,"k-")
ylabel = "$\Gamma/1e32$"
xlabel = "Log R/R$_g$             "
ax.Axes.set_ylabel(insetaxes,ylabel,labelpad=-5)
ax.Axes.set_xlabel(insetaxes,xlabel,labelpad=-5)
#plt.xlabel(xlabel)
#ax.xaxis.LABELPAD = 10
plt.ylim(-1,1)
plt.xlim(0.5,3)
plt.setp(insetaxes,xticks=[1,2,3],yticks=[-1,0,1])
plt.plot(logRg,np.zeros(len(logRg)),"r--")

plt.show()
#plt.savefig("torque_inset.png")

##################################
#### Mordecai's plot idea ####
##################################

logRg = np.array(logRg)
#negmask = [0 > Torque]  # also works.  returns T/F
#negative = np.where(Torque < 0.0)
positive = np.where(Torque >= 0.0)
PosTork = Torque[positive]
PosR = logRg[positive]
positive1 = np.where(PosR < 1.4)
positive2 = np.where(PosR > 2.0)

# break in positive values is from 1.387 - 2.119


a=axes([0.125,0.15,0.8,0.8])
plt.plot(logRg,abs(Torque/1e49),"k-",label="negative")
#plt.plot(logRg[negative],abs(Torque[negative]/1e49),"r-")
plt.plot(PosR[positive1],abs(PosTork[positive1]/1e49),"r-",linewidth=2.0,label="positive")
plt.plot(PosR[positive2],abs(PosTork[positive2]/1e49),"r-",linewidth=2.0)
plt.xlim(0.5,5)
plt.ylim(1e-12,10)
plt.yscale("log")
ax.Axes.set_xlabel(a,"Log Radius (R/R$_g$)",labelpad=15,size=20)
ax.Axes.set_ylabel(a,"abs($\Gamma)/1e49$ ",labelpad=-7,size=20)
ax.Axes.set_yticks(a,[1e-12,1e-10,1e-8,1e-6,1e-4,1e-2])
plt.legend(loc=4)
### ARROWS!!! ###
width=1
headwidth=5
# second trap
a.annotate(" ",xy=(2.6,3e-4),xytext=(2.85,3e-4),arrowprops=dict(facecolor='black',shrink=0.005,width=width,headwidth=headwidth),)
a.annotate(" ",xy=(2.45,3e-4),xytext=(2.25,3e-4),arrowprops=dict(facecolor='black',shrink=0.005,width=width,headwidth=headwidth),)
# first trap
a.annotate(" ",xy=(1.35,5e-9),xytext=(1.1,5e-9),arrowprops=dict(facecolor='black',shrink=0.005,width=width,headwidth=headwidth),)
a.annotate(" ",xy=(1.45,5e-9),xytext=(1.7,5e-9),arrowprops=dict(facecolor='black',shrink=0.005,width=width,headwidth=headwidth),)
### vertical dashed lines
#plt.plot([trapradius[0],trapradius[0]],[1e-14,100],"b--")
#plt.plot([trapradius[1],trapradius[1]],[1e-14,100],"b--")
#plt.plot([untrap[1],untrap[1]],[1e-14,100],"b--")
#plt.plot([untrap[0],untrap[0]],[1e-14,100],"b--")
### plus and minus signs
ylocation = 1e-11
#plt.text(1.05,ylocation,"+",size=30)
#plt.text(2.25,ylocation,"+",size=30)
#plt.text(1.7,ylocation,"-",size=30)
#plt.text(3.0,ylocation,"-",size=30)
#plt.text(0.6,ylocation,"-",size=30)


## holy shit what if I make an inset here
"""insetaxes = axes([.58,.3,.3,.3])
#a = axes([0.1,0.15,.8,.8])
plt.plot(logRg,Torque/1e49,"k-")
plt.plot(PosR[positive1],PosTork[positive1]/1e49,"r-",linewidth=2.0)
plt.plot(PosR[positive2],PosTork[positive2]/1e49,"r-",linewidth=2.0)
ylabel = "$\Gamma/1e49$"
xlabel = "Log R/R$_g$"
ax.Axes.set_ylabel(insetaxes,ylabel,labelpad=-10)
ax.Axes.set_xlabel(insetaxes,xlabel,labelpad=10)
#plt.xlabel(xlabel)
#ax.xaxis.LABELPAD = 10
plt.ylim(-1,.2)
plt.xlim(0.5,5)
plt.setp(insetaxes,xticks=[1,2,3,4,5],yticks=[-1,0,.2])
plt.plot(logRg,np.zeros(len(logRg)),"b--")
"""



#plt.show()
#plt.savefig("torque_abs.png")

##########################
## Reversed inset plot  ##
##########################
"""
import matplotlib.axes as ax
from pylab import axes

a = axes([0.1,0.15,.8,.8])
#insetaxes = axes([.18,.82,.4,.1])
plt.plot(logRg,Torque/1e32)
plt.axis([0.0,5.0,-1.0,0.4])
#plt.xlabel("Log Radius R/R$_g$")
#plt.ylabel("$\Gamma/1e49$")
ax.Axes.set_ylabel(a,"$\Gamma/1e32$",labelpad=0,size=20)
ax.Axes.set_xlabel(a,"Log Radius (R/R$_g$)",labelpad=5,size=20)
plt.plot(logRg,np.zeros(len(logRg)),"r--")


insetaxes = axes([.58,.3,.3,.3])
#a = axes([0.1,0.15,.8,.8])
plt.plot(logRg,Torque/1e49)
ylabel = "$\Gamma/1e49$"
xlabel = "Log R/R$_g$"
ax.Axes.set_ylabel(insetaxes,ylabel,labelpad=-10)
ax.Axes.set_xlabel(insetaxes,xlabel,labelpad=10)
#plt.xlabel(xlabel)
#ax.xaxis.LABELPAD = 10
plt.ylim(-1,.2)
plt.xlim(0.5,5)
plt.setp(insetaxes,xticks=[1,2,3,4,5],yticks=[-1,0,.2])
plt.plot(logRg,np.zeros(len(logRg)),"r--")

#plt.show()
#plt.savefig("torque_inset_reverse.png")

"""

#  if I flatten out the temp profile at second TMQ jump, do I get trap?
# i.e. if I do not accentuate the little surface density jump

# is there an "intuitive" way to see the traps by looking at the equations?

# magnitude of surface density jump - how large is larg?

