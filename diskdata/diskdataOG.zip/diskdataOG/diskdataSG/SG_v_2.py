import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
import scipy.interpolate as interpol

#This is Saavik screwing with Jillian's code.
#Original in thing.py
#corrected unit error in cv
#Saavik wants surface density, sound speed and h (aspect ratio) as a fn of disk radius
#(and possibly later will want other quantities e.g. c_s)
# goal: to interpolate Sirko & Goodman fits

# # # # # # # # # # # # # # # # # # # # # # # # 
# CONSTANTS AND INPUT VARIABLES
# # # # # # # # # # # # # # # # # # # # # # # # 
M_SMBH = 1e8            # guess at SMBH mass!
#M_SMBH = 1e9
M_IMBH = 100.0           # what is the IMBH mass?  Who knows right now.
q = M_IMBH/M_SMBH       # ratio of planet/central object masses. 
Gcgs = 6.67e-8          # G in cgs units.  
cv = 12.5e7               # 12.5 monatomic gas, 20.8 diatomic.(x1.0e7 for cgs units!)
sigma_SB = 5.67e-5      # cgs units!
speedoflight = 3e10     # cm / s
Msung = 2.0e33            # convert solar mass to grams
M_SMBH_gram = M_SMBH*Msung
#M_SMBH_gram2 = M_SMBH2*Msung
Rs = 2*Gcgs*M_SMBH_gram/speedoflight**2  # schwartzshield radius in cm
#Rs2 = 2*Gcgs*M_SMBH_gram2/speedoflight**2  # schwartzshield radius in cm
pctocm = 3.0856776e+18  # parsecs to cm
# # # # # # # # # # # # # # # # # # # # # # # # 

#  FUNCTIONS
##############################
# take a derivative 
##############################
def derivative(x,y):
    """ returns derivative of one array wrt the other.
        result is one element shorter than original arrays, hmm """
    if len(x) != len(y):
        print "x and y must have equal lengths"
    result =[]
    for element in range(len(x)-1):
        dy = y[element+1]-y[element]
        dx = x[element+1]-x[element]
        result.append(dy/dx)
    result.append(result[-1]) # append the final value onto the end!
    # this is sketchy.
    return result

###############################################
#  Let's find the migration traps with math
###############################################
def findtrap(R,Torque):
    trap=[]
    for i in range(len(Torque)-1):
        if Torque[i] > 0 and Torque[i+1] < 0:
            trap.append(i)
    trapradius=[]
    for j in range(len(trap)):
        ###print R[trap[j]]
        trapradius.append(R[trap[j]])
    return trapradius

### this one finds the unstable traps ###
def finduntrap(R,Torque):
    untrap=[]
    for i in range(len(Torque)-1):
        if Torque[i] < 0 and Torque[i+1] > 0:
            untrap.append(i)
    untrapradius=[]
    for j in range(len(untrap)):
        ###print R[trap[j]]
        untrapradius.append(R[untrap[j]])
    return untrapradius
####################################

### Temperature vs Radius data ###
r1,temp = np.loadtxt("Temp.txt",unpack=True,delimiter=",")
logschwarzradius = np.arange(5500)/1000.  # this is log R/Rs
#logradius = np.arange(5500)/1000.  # this is log R/Rs
# radius needs to be within the bounds of r1
awesome = []
for item in logschwarzradius:
    if item > min(r1) and item < max(r1):
        awesome.append(item)
radiuscm = np.power(10,awesome)*Rs
radiuspc = radiuscm/pctocm
logradius = np.log10(radiuspc)  # new radius in log pc
# rescale r1 as well
r1 = np.log10(np.power(10,r1)*Rs/pctocm) # convert Log R/Rs to Log pc
logRg = awesome

### Temperature INTERPOLATION ###
# quick and dirty interpolation
f = interpol.interp1d(r1,temp)
tnew = f(logradius)
# spline interpolation
f2 = interpol.splrep(r1,temp,s=0)
tnew2 = interpol.splev(logradius,f2,der=0)

"""plt.subplot(221)
plt.plot(r1,temp,"o",logradius,tnew,"-",logradius,tnew2,"--")
plt.xlabel("log R/Rs")
plt.ylabel("log T (K)")
#plt.show()"""

# need to un-log our values.
radius = np.power(10,logradius)
unlogtemp = np.power(10,tnew)
unlogtemp2 = np.power(10,tnew2)

# let's calculate the derivative of our new function.

# sympy
# numpy.diff
# numpy.gradient
# scipy.misc.derivative  -  this is the one to try.
#import sympy
#meow = sympy.mpmath.diff(tnew,logradius)

d1temp = derivative(np.log(radiuscm),np.log(unlogtemp))
d2temp = derivative(np.log(radiuscm),np.log(unlogtemp2))
#d2temp2 = derivative(np.log(np.array(radius)*Rs2),np.log(unlogtemp2))

"""plt.subplot(222)
plt.plot(logradius,d1temp,logradius,d2temp)
plt.ylabel("d ln T/d ln R")
plt.xlabel("log R (pc)")
"""

# let's repeat this in log pc
#radius_parsec = np.array(radius)*Rs/pctocm
#radius_parsec2 = np.array(radius)*Rs2/pctocm
#log_radius_parsec = np.log10(radius_parsec)
#log_radius_parsec2 = np.log10(radius_parsec2)
#plt.subplot(223)
#plt.plot(log_radius_parsec,tnew2,log_radius_parsec2,tnew2)
#plt.xlabel("log radius (parsec)")

#parsecd2temp = derivative(np.log(radius_parsec),np.log(unlogtemp2))
#parsecd2temp2 = derivative(np.log(radius_parsec2),np.log(unlogtemp2))
#plt.subplot(224)
#plt.plot(log_radius_parsec,parsecd2temp,log_radius_parsec2,parsecd2temp2)
#plt.ylabel("d ln T/d ln R")
#plt.xlabel("log radius (pc)")
#plt.show()

###########  now for surface density ##############
r2,Sigma = np.loadtxt("SurfaceDensity.txt",unpack=True,delimiter=",")
r2 = np.log10(np.power(10,r2)*Rs/pctocm) # convert Log R/Rs to Log pc

# interpolate
f = interpol.interp1d(r2,Sigma)
tnew = f(logradius)
f2 = interpol.splrep(r2,Sigma,s=0)
tnew2 = interpol.splev(logradius,f2,der=0)

#plt.subplot(223)
#plt.plot(r2,Sigma,"o",logradius,tnew,"-",logradius,tnew2,"--")
#plt.xlabel("log R/Rs")
#plt.ylabel("log Surface Density")

# unlog the quantities for derivative-ing
unlogsigma = np.power(10,tnew)
unlogsigma2 = np.power(10,tnew2)


d1sigma = derivative(np.log(radiuscm),np.log(unlogsigma))
d2sigma = derivative(np.log(radiuscm),np.log(unlogsigma2))

#plt.subplot(224)
#plt.plot(logradius,d1sigma,logradius,d2sigma)
#plt.ylabel("d ln(Sigma)/d ln R")
#plt.xlabel("log R/Rs")
#plt.show()


#### other quantities I need ####
### half-height of disk h ###
rh,loghoverr = np.loadtxt("hoverr.txt",unpack=True,delimiter=",")
rh = np.log10(np.power(10,rh)*Rs/pctocm) # convert Log R/Rs to Log pc

# interpolate h
f2 = interpol.splrep(rh,loghoverr,s=0)
hnew2 = interpol.splev(logradius,f2,der=0)  # note this is log h/r, not h
hoverr = np.power(10,hnew2) # disk aspect ratio

# need tau_eff, start with tau.
rtau, logtau = np.loadtxt("tau.txt",unpack=True,delimiter=",")
rtau = np.log10(np.power(10,rtau)*Rs/pctocm) # convert Log R/Rs to Log pc

f2tau = interpol.splrep(rtau,logtau,s=0)
taunew2 = interpol.splev(logradius,f2tau,der=0)
tau = np.power(10.0,taunew2)  # unlog the tau
taueff = (3.*np.array(tau))/8. + np.sqrt(3.)/4. + 1./(4.*np.array(tau)) # from Lyra+10

#plt.subplot(211)
#plt.plot(logradius,tau)
#plt.yscale("log")
#plt.subplot(212)
#plt.plot(logradius,taueff)
#plt.yscale("log")
#plt.show()

Omega = np.sqrt(Gcgs*M_SMBH_gram/(radiuscm)**3) # is Keplerian Frequency same as ang vel?
Gamma_0 = (q/hoverr)**2 * unlogsigma * (radiuscm)**4 * np.array(Omega)**2
Theta = (cv*unlogsigma*Omega*taueff)/(12*np.pi*sigma_SB*unlogtemp2**3)
print Theta
print "that was theta"

####  now let's calculate some torques.  ####

alpha = -1.0 *np.array(d2sigma)
beta =  (-1.0) * np.array(d2temp)
gamma = 1.667  # monotonic gas, not 1.4 as in Lyra+10
xi = beta - np.array(alpha)*(gamma-1.0)

Gamma_iso = -0.85 - alpha - 0.9*beta 
Gamma_ad = (-0.85 - alpha - 1.7*beta + 7.9*xi/gamma)/gamma

