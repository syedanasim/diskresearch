#### fix c_v before doing any more science ####

import numpy as np
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
import scipy.interpolate as interpol


# goal: to interpolate Thompson et al 2005 fits and then take derivatives
# get the torque vs radius for a SMBH accretion disk.

# # # # # # # # # # # # # # # # # # # # # # # # 
# CONSTANTS AND INPUT VARIABLES
# # # # # # # # # # # # # # # # # # # # # # # # 
M_SMBH = 1e9            # guess at SMBH mass!
M_IMBH = 100.0           # what is the IMBH mass?  Who knows right now.
q = M_IMBH/M_SMBH       # ratio of planet/central object masses. 
Gcgs = 6.67e-8          # G in cgs units.  what units?
cv = 12.5               # 12.5 monatomic gas, 20.8 diatomic. 
#### this is wrong should be 12.5e7 !!!!! ######  change before doing anything
sigma_SB = 5.67e-5      # cgs units!
speedoflight = 3e10     # cm / s
Msung = 2e33            # convert solar mass to grams
M_SMBH_gram = M_SMBH*Msung
Rs = 2*Gcgs*M_SMBH_gram/speedoflight**2  # schwartzshield radius in cm
pctocm = 3.0856776e+18  # parsecs to cm
# # # # # # # # # # # # # # # # # # # # # # # # 

#  FUNCTIONS
##############################
# take a derivative 
##############################
def derivative(x,y):
    """ returns derivative of one array wrt the other.
        result is one element shorter than original arrays, hmm """
    if len(x) != len(y):
        print "x and y must have equal lengths"
    result =[]
    for element in range(len(x)-1):
        dy = y[element+1]-y[element]
        dx = x[element+1]-x[element]
        result.append(dy/dx)
    result.append(result[-1]) # append the final value onto the end!
    # this is sketchy.
    return result

###############################################
#  Let's find the migration traps with math
###############################################
def findtrap(R,Torque):
    trap=[]
    for i in range(len(Torque)-1):
        if Torque[i] > 0 and Torque[i+1] < 0:
            trap.append(i)
    trapradius=[]
    for j in range(len(trap)):
        ###print R[trap[j]]
        trapradius.append(R[trap[j]])
    return trapradius

### this one finds the unstable traps ###
def finduntrap(R,Torque):
    untrap=[]
    for i in range(len(Torque)-1):
        if Torque[i] < 0 and Torque[i+1] > 0:
            untrap.append(i)
    untrapradius=[]
    for j in range(len(untrap)):
        ###print R[trap[j]]
        untrapradius.append(R[untrap[j]])
    return untrapradius
####################################


# HACK
# if radius r1 = discontinuity point then change it a bit for each read-in.
# also -0.81, -0.84, -1.65, -1.63

oldvalue1 = -1.65
newvalue1 = -1.65#  70
oldvalue2 = -1.63
newvalue2 = -1.63 # 58
oldvalue3 = -0.84
newvalue3 = -0.84 #91
oldvalue4 = -0.81
newvalue4 = -0.81 #0


### Temperature vs Radius data ###
r1,temp = np.loadtxt("Temp.txt",unpack=True,delimiter=",")
#HACK
for item in range(len(r1)):
    if r1[item] == oldvalue1:
        r1[item] = newvalue1
#        print "one"
    if r1[item] == oldvalue2:
        r1[item] = newvalue2
#        print "two"
    if r1[item] == oldvalue3:
        r1[item] = newvalue3
#        print "three"
    if r1[item] == oldvalue4:
        r1[item] = newvalue4
#        print "four"


logradius = np.arange(6300)/1000. - 4.0  # this is log R in pc
# radius needs to be within the bounds of r1
awesome = []
for item in logradius:
    if item > min(r1) and item < max(r1):
        awesome.append(item)

logradius = awesome
# convert to Rg
unlogradius = np.power(10,logradius)
logRg = np.log10(unlogradius*pctocm/Rs)


### TEMPERATURE INTERPOLATION ###
# quick and dirty interpolation
f = interpol.interp1d(r1,temp)
tnew = f(logradius)
# spline interpolation
#f2 = interpol.splrep(r1,temp,s=0)
#tnew2 = interpol.splev(logradius,f2,der=0)

#plt.subplot(221)
#plt.plot(r1,temp,"o",logradius,tnew,"-")#,logradius,tnew2,"--")
#plt.xlabel("log R")
#plt.ylabel("log T (K)")
#plt.show()

# need to un-log our values.
radius = np.power(10,logradius)
unlogtemp = np.power(10,tnew)
#unlogtemp2 = np.power(10,tnew2)

# let's calculate the derivative of our new function.

# sympy
# numpy.diff
# numpy.gradient
# scipy.misc.derivative  -  this is the one to try.
#import sympy
#meow = sympy.mpmath.diff(tnew,logradius)

d1temp = derivative(np.log(radius*pctocm),np.log(unlogtemp))
#d2temp = derivative(np.log(radius),np.log(unlogtemp2))

#plt.subplot(222)
#plt.plot(logradius,d1temp)#,logradius,d2temp)
#plt.ylabel("d ln T/d ln R")
#plt.xlabel("log R")
#plt.show()

###########  now for surface density ##############
r2,Sigma = np.loadtxt("SurfaceDensity.txt",unpack=True,delimiter=",")
#HACK
for item in range(len(r2)):
    if r2[item] == oldvalue1:
        r2[item] = newvalue1
    if r2[item] == oldvalue2:
        r2[item] = newvalue2
    if r2[item] == oldvalue3:
        r2[item] = newvalue3
    if r2[item] == oldvalue4:
        r2[item] = newvalue4


# interpolate
f = interpol.interp1d(r2,Sigma)
tnew = f(logradius)
#f2 = interpol.splrep(r2,Sigma,s=0)
#tnew2 = interpol.splev(logradius,f2,der=0)

#plt.subplot(223)
#plt.plot(r2,Sigma,"o",logradius,tnew,"-")#,logradius,tnew2,"--")
#plt.xlabel("log R")
#plt.ylabel("log Surface Density")
#plt.show()
#plt.savefig("SurfaceDensity.png")

# unlog the quantities for derivative-ing
unlogsigma = np.power(10,tnew)
#unlogsigma2 = np.power(10,tnew2)

d1sigma = derivative(np.log(radius*pctocm),np.log(unlogsigma))
#d2sigma = derivative(np.log(radius),np.log(unlogsigma2))

#plt.subplot(224)
#plt.plot(logradius,d1sigma)#,logradius,d2sigma)
#plt.ylabel("d ln(Sigma)/d ln R")
#plt.xlabel("log R")
#plt.show()

#### other quantities I need ####
### half-height of disk h ###
rh,loghoverr = np.loadtxt("hoverr.txt",unpack=True,delimiter=",")
#HACK
for item in range(len(rh)):
    if rh[item] == oldvalue1:
        rh[item] = newvalue1
    if rh[item] == oldvalue2:
        rh[item] = newvalue2
    if rh[item] == oldvalue3:
        rh[item] = newvalue3
    if rh[item] == oldvalue4:
        rh[item] = newvalue4



# interpolate h
f2 = interpol.interp1d(rh,loghoverr)
hnew2 = f2(logradius)  # note this is log h/r, not h
hoverr = np.power(10,hnew2) # disk aspect ratio

# need tau_eff, start with tau.
rtau, logtau = np.loadtxt("tau.txt",unpack=True,delimiter=",")
#HACK
for item in range(len(rtau)):
    if rtau[item] == oldvalue1:
        rtau[item] = newvalue1
    if rtau[item] == oldvalue2:
        rtau[item] = newvalue2
    if rtau[item] == oldvalue3:
        rtau[item] = newvalue3
    if rtau[item] == oldvalue4:
        rtau[item] = newvalue4


f2tau = interpol.interp1d(rtau,logtau)
taunew2 = f2tau(logradius)
tau = np.power(10.0,taunew2)  # unlog the tau
taueff = (3.*np.array(tau))/8. + np.sqrt(3.)/4. + 1./(4.*np.array(tau)) # from Lyra+10

#plt.subplot(211)
#plt.plot(rtau,logtau,'o',logradius,taunew2,'-')
#plt.yscale("log")
#plt.subplot(212)
#plt.plot(logradius,taueff)
#plt.yscale("log")
#plt.show() 

Omega = np.sqrt(Gcgs*M_SMBH_gram/np.array(radius*pctocm)**3) # is Keplerian Frequency same as ang vel?
Gamma_0 = (q/hoverr)**2 * unlogsigma * np.array(radius*pctocm)**4 * np.array(Omega)**2
Theta = (cv*unlogsigma*Omega*taueff)/(12*np.pi*sigma_SB*unlogtemp**3)


####  now let's calculate some torques.  ####

alpha = -1.0 *np.array(d1sigma)
beta =  (-1.0) * np.array(d1temp)
gamma = 1.667  # monotonic gas, not 1.4 as in Lyra+10
xi = beta - np.array(alpha)*(gamma-1.0)

Gamma_iso = -0.85 - alpha - 0.9*beta 
Gamma_ad = (-0.85 - alpha - 1.7*beta + 7.9*xi/gamma)/gamma

# plot some test quantities
"""plt.subplot(221)
plt.plot(logradius,taueff)
plt.yscale("log")
plt.xlabel("Log R")
plt.ylabel("taueff")
plt.subplot(222)
plt.plot(logradius,Omega)
plt.yscale("log")
plt.ylabel("Omega  sqrt(GM/r^3)")
plt.xlabel("Log R")
#plt.show()
plt.subplot(223)
plt.plot(rh,loghoverr,'o',logradius,np.log10(hoverr),'-')
plt.ylabel("Log h/r")
plt.xlabel("Log R") """
#plt.subplot(224)

"""plt.subplot(221)
plt.plot(logradius,alpha)
plt.ylabel("alpha")
plt.subplot(222)
plt.plot(logradius,beta)
plt.ylabel("beta")
plt.subplot(223)
plt.plot(logradius,xi)
plt.ylabel("xi")
plt.subplot(224)
plt.plot(logradius,Gamma_iso,logradius,Gamma_ad)
plt.ylabel("Gammas")
plt.xlabel("Log R")
#plt.show()"""

"""plt.subplot(211)
plt.plot(logradius,Gamma_0)
plt.xlabel("log R")
plt.ylabel("Gamma_0")
plt.yscale("log")
plt.subplot(212)
plt.plot(logradius,Theta)
plt.yscale("log")
plt.ylabel("Theta")
#plt.subplot(223)
#plt.plot(logradius,xi)
#plt.ylabel("xi")
plt.show()"""


Torque = (Gamma_ad*np.array(Theta)**2 + Gamma_iso)*Gamma_0 / (np.array(Theta)+1)**2

trapradius = findtrap(logRg,Torque)
untrap = finduntrap(logRg,Torque)
print trapradius
#print np.power(10,trapradius), " parsecs"

#othertrapradius = findtrap(radius,Torque)
#print othertrapradius


# rescale?
#Torque = Torque * unlogsigma2/unlogtemp2

#plt.subplot(211)
#plt.plot(logradius,np.abs(Torque))
#plt.xlabel("Log Radius")
#plt.ylabel("Abs Torque (cgs units)")
#plt.yscale("log")
#plt.plot(logradius,np.zeros(len(logradius)),"r--")
"""
plt.subplot(211)
plt.plot(logRg,Torque/1e50)
#plt.xlabel("Log Radius")
plt.ylabel("$\Gamma$/1e50 (cgs units)")
plt.xlim(0,5)
plt.plot(logRg,np.zeros(len(logradius)),"r--")


plt.subplot(212)
plt.plot(logRg,Torque/1e47)
plt.xlabel("Log Radius (R/Rg)")
plt.ylabel("$\Gamma$ /1e47 ZOOM IN")
plt.ylim(-1,1)
plt.xlim(2,2.6)
plt.plot(logRg,np.zeros(len(logradius)),"r--")

#plt.subplot(313)
#plt.plot(logradius,abs(Torque/1e50))
#plt.xlabel("Log Radius")
#plt.ylabel("|$\Gamma$|/1e50 (cgs units)")
#plt.ylim(0,300)
#plt.plot(logradius,np.zeros(len(logradius)),"r--")



plt.show()
#plt.savefig("torque.png")
"""
##########################
## make an inset plot  ##
##########################
"""
import matplotlib.axes as ax
from pylab import axes

a = axes([0.1,0.15,.8,.8])
plt.plot(logRg,Torque/1e49,"k-")
plt.axis([1.0,5.0,-1.0,0.4])
#plt.xlabel("Log Radius R/R$_g$")
#plt.ylabel("$\Gamma/1e49$")
ax.Axes.set_ylabel(a,"$\Gamma/1e49$",labelpad=0,size=20)
ax.Axes.set_xlabel(a,"Log Radius (R/R$_g$)",labelpad=5,size=20)
plt.plot(logRg,np.zeros(len(logRg)),"r--")


insetaxes = axes([.2,.25,.3,.1])
plt.plot(logRg,Torque/1e32,"k-")
ylabel = "$\Gamma/1e32$"
xlabel = "          Log R/R$_g$"
ax.Axes.set_ylabel(insetaxes,ylabel,labelpad=-5)
ax.Axes.set_xlabel(insetaxes,xlabel,labelpad=0)
#plt.xlabel(xlabel)
#ax.xaxis.LABELPAD = 10
plt.ylim(-1,1)
plt.xlim(1.5,3)
plt.setp(insetaxes,xticks=[1.5,2,3],yticks=[-1,0,1])
plt.plot(logRg,np.zeros(len(logRg)),"r--")

#plt.show()
#plt.savefig("torque_inset.png")
"""
##########################
## make an abs plot  ##
##########################


logRg = np.array(logRg)
#negmask = [0 > Torque]  # also works.  returns T/F
#negative = np.where(Torque < 0.0)
positive = np.where(Torque >= 0.0)
PosTork = Torque[positive]
PosR = logRg[positive]

a=axes([0.125,0.15,0.8,0.8])
plt.plot(logRg,abs(Torque/1e49),"k-",label="negative")
plt.plot(PosR,abs(PosTork/1e49),"r-",linewidth=2.0,label="positive")
plt.xlim(0.5,5)
plt.ylim(1e-10,100)
plt.yscale("log")
ax.Axes.set_xlabel(a,"Log Radius (R/R$_g$)",labelpad=15,size=20)
ax.Axes.set_ylabel(a,"abs($\Gamma)/1e49$ ",labelpad=-7,size=20)
#ax.Axes.set_yticks(a,[1e-12,1e-10,1e-8,1e-6,1e-4,1e-2])
plt.legend(loc=4)

### ARROWS!!! ###
width=1
headwidth=5
# second trap
#a.annotate(" ",xy=(2.6,3e-4),xytext=(2.85,3e-4),arrowprops=dict(facecolor='black',shrink=0.005,width=width,headwidth=headwidth),)
#a.annotate(" ",xy=(2.45,3e-4),xytext=(2.25,3e-4),arrowprops=dict(facecolor='black',shrink=0.005,width=width,headwidth=headwidth),)

### vertical dashed lines
#plt.plot([trapradius[0],trapradius[0]],[1e-14,100],"b--")
#plt.plot([untrap[0],untrap[0]],[1e-14,100],"b--")


insetaxes = axes([.53,.4,.28,.18])
plt.plot(logRg,Torque/1e49,'k-')
plt.plot(PosR,PosTork/1e49,'r-',linewidth=2.0)
ylabel = "$\Gamma/1e49$"
xlabel = " Log R/R$_g$"
ax.Axes.set_ylabel(insetaxes,ylabel,labelpad=-5)
ax.Axes.set_xlabel(insetaxes,xlabel,labelpad=8)
plt.ylim(-5,10)
plt.xlim(2.2,2.5)

plt.setp(insetaxes,xticks=[2.2,2.3,2.4,2.5],yticks=[-4,0,4,8])
#plt.plot(logRg,np.zeros(len(logRg)),"r--")
#plt.plot(logRg,np.zeros(len(logradius)),"r--")


plt.show()
#plt.savefig("torque_abs.png")

